from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
import random
from app.db.models import Level, Topic, Question

async def get_interview_questions(
    session: AsyncSession, 
    level_name: str, 
    topic_name: str = None
) -> dict:
    """
    Получает вопросы для заданного уровня. 
    Если тема не указана, выбирает случайную тему для этого уровня.
    """
    
    # 1. Ищем уровень
    stmt = select(Level).where(Level.name == level_name)
    result = await session.execute(stmt)
    level = result.scalars().first()
    
    if not level:
        return None

    # 2. Выбираем тему
    stmt_topics = select(Topic).where(Topic.level_id == level.id)
    if topic_name:
        stmt_topics = stmt_topics.where(Topic.name == topic_name)
    
    # Подгружаем сразу вопросы, чтобы не делать лишних запросов (Eager loading)
    stmt_topics = stmt_topics.options(selectinload(Topic.questions))
    
    result_topics = await session.execute(stmt_topics)
    topics = result_topics.scalars().all()
    
    if not topics:
        return None

    # Если тема не была выбрана конкретно, берем случайную из доступных
    selected_topic = random.choice(topics)
    
    return {
        "level": level.name,
        "topic": selected_topic.name,
        "questions": [q.text for q in selected_topic.questions]
    }
